using System.Text;
using System.Text.Json;

namespace CLDokterspraktijk.Debug;

// =============================================================================
// DebugAgentLog — tijdelijke NDJSON-logging (ontwikkeling)
// =============================================================================
// Schrijft naar debug-232d3f.log in solution-root; geen UI; niet voor eindgebruiker.
// =============================================================================
public static class DebugAgentLog
{
    private const string LogFileName = "debug-232d3f.log";
    private static readonly object _objLock = new object();

    private static string ResolveLogPath()
    {
        string? dir = AppContext.BaseDirectory;
        for (int i = 0; i < 10 && dir != null; i++)
        {
            string strCandidate = Path.Combine(dir, LogFileName);
            if (File.Exists(strCandidate))
            {
                return strCandidate;
            }

            if (Directory.GetFiles(dir, "*.slnx").Length > 0 || Directory.GetFiles(dir, "*.sln").Length > 0)
            {
                return strCandidate;
            }

            dir = Directory.GetParent(dir)?.FullName;
        }

        return Path.Combine(AppContext.BaseDirectory, LogFileName);
    }

    public static void Write(string location, string message, object? data = null, string? hypothesisId = null, string? runId = null)
    {
        // #region agent log
        lock (_objLock)
        {
            try
            {
                Dictionary<string, object?> dictEntry = new Dictionary<string, object?>
                {
                    ["sessionId"] = "232d3f",
                    ["timestamp"] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    ["location"] = location,
                    ["message"] = message,
                    ["data"] = data,
                    ["hypothesisId"] = hypothesisId,
                    ["runId"] = runId
                };
                string strLine = JsonSerializer.Serialize(dictEntry) + Environment.NewLine;
                string strPath = ResolveLogPath();
                using (FileStream stmLog = new FileStream(strPath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                {
                    using (StreamWriter writer = new StreamWriter(stmLog, Encoding.UTF8))
                    {
                        writer.Write(strLine);
                    }
                }
            }
            catch
            {
            }
        }
        // #endregion
    }
}
